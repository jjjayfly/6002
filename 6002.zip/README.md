# TSAD

This repository holds experiment codes and research reports of the Time Series Anomaly Detection project for SDSC6002 at CityU of HK.

## TODO

25 Feb 2021

- Enrich our reports with a more systematic illustrate, including add content in traditional time series analysis, uniform symbols among different models, use more table and figures for visualization
- Try to implement methods(except TCN) in Bai's paper and generate a vanilla comparison by our own
- Try to find some easy-to-start data to reproduce related papers' model and their experiments
